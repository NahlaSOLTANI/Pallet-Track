package com.example.PalleTracker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PalleTrackerApplicationTests {

	@Test
	void contextLoads() {
	}

}
