package com.example.PalleTracker.Entities;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import org.hibernate.annotations.CollectionId;
import org.hibernate.annotations.CreationTimestamp;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.text.SimpleDateFormat;
import java.util.Date;

import javax.persistence.*;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;
@Document(collection ="Pallet")
@JsonIgnoreProperties(ignoreUnknown = true)
public class Pallet {
    @Id
    @JsonIgnore
    private Long palletID ;
    private String palletState;

    private Date palletDateCreation;
    private Boolean palletActive;
    private String palletCreator ;
    public Pallet(String palletState, Boolean palletActive, String palletCreator) {
        SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
        Date date = new Date(System.currentTimeMillis());
        this.palletDateCreation=date;
        this.palletState = palletState;
        this.palletActive = palletActive;
        this.palletCreator = palletCreator;
    }
    public Pallet() {
    }



    public Long getPalletID() {
        return palletID;
    }

    public void setPalletID( Long palletID) {
        this.palletID = palletID;
    }

    public String getPalletState() {
        return palletState;
    }

    public void setPalletState(String palletState) {
        this.palletState = palletState;
    }

    public Date getPalletDateCreation() {
        return palletDateCreation;
    }

    public void setPalletDateCreation(Date palletDateCreation) {
        this.palletDateCreation = palletDateCreation;
    }

    public Boolean getPalletActive() {
        return palletActive;
    }

    public void setPalletActive(Boolean palletActive) {
        this.palletActive = palletActive;
    }

    public String getPalletCreator() {
        return palletCreator;
    }

    public void setPalletCreator(String palletCreator) {
        this.palletCreator = palletCreator;
    }

    @Override
    public String toString() {
        return "Pallet{" +
                "palletID='" + palletID + '\'' +
                ", palletState='" + palletState + '\'' +
                ", palletDateCreation=" + palletDateCreation +
                ", palletActive=" + palletActive +
                ", palletCreator='" + palletCreator + '\'' +
                '}';
    }
}
