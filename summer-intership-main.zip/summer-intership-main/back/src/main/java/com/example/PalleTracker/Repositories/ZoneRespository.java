package com.example.PalleTracker.Repositories;

import com.example.PalleTracker.Entities.Zone;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

@RepositoryRestResource
public interface ZoneRespository  extends MongoRepository<Zone,Long>{








}

