package com.example.PalleTracker.Controller;

import com.example.PalleTracker.Entities.DatabaseSequence;
import com.example.PalleTracker.Entities.Pallet;
import com.example.PalleTracker.Entities.Zone;
import com.example.PalleTracker.Repositories.DataBaseSequenceeRespository;
import com.example.PalleTracker.Repositories.PalletRepository;
import com.example.PalleTracker.Repositories.ZoneRespository;
import com.example.PalleTracker.Service.PalletService;
import com.example.PalleTracker.Service.ZoneService;
import org.joda.time.DateTimeZone;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.TimeZone;

@RestController
public class ZoneController {
   @Autowired
   private ZoneService service ;
   @Autowired
   private DataBaseSequenceeRespository repo;

   @PostMapping("/addzone")
   public String AddZone(@RequestBody Zone zone){
      TimeZone.setDefault(TimeZone.getTimeZone("UTC"));

      Date date = new Date(System.currentTimeMillis());
      DateTimeZone timeZone = DateTimeZone.forID( "Africa/Tunis" );
      DatabaseSequence dbs=repo.findById("zone");
      if( dbs==null ){
         dbs=new DatabaseSequence();
         dbs.setId("zone");
         dbs.setSeqVal(0);
         repo.save(dbs);
      }
      zone.setZoneId(dbs.getSeqVal()+1);
      dbs.setSeqVal(dbs.getSeqVal()+1);
      repo.save(dbs);
      zone.setZoneDateCreation(date);
      service.saveOrUpdateZone(zone);
      return "Zone added with id :" +zone.getZoneId();}
   @GetMapping("/zones")
   public List<Zone> getZones (){
      return service.getZones();

   }
   @GetMapping("/zone/{id}")
   public Zone getPallet(@PathVariable Long id){
      return service.getZoneById(id)  ; }
   @DeleteMapping("/deletezone/{id}")
   public String deleteZone(@PathVariable Long id){
      service.deletezone(id);
      return "pallet deleted with id : "+id;
   }
   @PostMapping("/zone")
   public Long savePallet(@RequestBody Zone Z)
   {
      service.saveOrUpdateZone(Z);
      return Z.getZoneId();
   }
   @PutMapping("/findzone/{id}")
   public Long updateZone(@PathVariable Long id,@RequestBody Zone  zone)
   {  TimeZone.setDefault(TimeZone.getTimeZone("UTC"));

      Date date = new Date(System.currentTimeMillis());
      DateTimeZone timeZone = DateTimeZone.forID( "Africa/Tunis" );
      zone.setZoneDateCreation(date);
      zone.setZoneId(id);
      service.saveOrUpdateZone(zone);
      return zone.getZoneId();
   }
   @GetMapping("/activezone")
   private List<Zone> getActive(){
      return service.getActiveZones();
   }
   @GetMapping("/inactivezone")
   private List<Zone> getInctive(){
      return service.getInactiveZones();
   }
}


