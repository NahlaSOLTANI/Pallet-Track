package com.example.PalleTracker.Service;

import com.example.PalleTracker.Entities.Pallet;
import com.example.PalleTracker.Repositories.DataBaseSequenceeRespository;
import com.example.PalleTracker.Repositories.PalletRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class PalletService {
    @Autowired
    private PalletRepository repository;

    public List<Pallet> getPallets (){
        return repository.findAll();}
    public Pallet gettById(Long id)
    {
        return repository.findById(id).get();
    }
    public void saveOrUpdatePallet(Pallet pallet)
    {
        repository.save(pallet);
    }
    public void deletePallet(Long id)
    {
        repository.deleteById(id);
    }
    public void update(Pallet p, Long palletid)
    {
        repository.save(p);
    }
    public List<Pallet> getStatePallet(String state ) {
        List<Pallet> list1 = getPallets();
        List<Pallet> listbyState=new ArrayList<>() ;
        for (Pallet p : list1)
        {
            if (p.getPalletState().equals(state)) {
                listbyState.add(p);
            }
        System.out.println(listbyState);        }
        return listbyState;
}}
