package com.example.PalleTracker.Repositories;

public class LoadTagRepository {
}
