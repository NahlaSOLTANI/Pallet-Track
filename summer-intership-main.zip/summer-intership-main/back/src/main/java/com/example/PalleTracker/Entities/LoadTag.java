package com.example.PalleTracker.Entities;

import org.springframework.data.annotation.Id;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;

public class LoadTag {
    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    private long LoadId ;

    public LoadTag() {
    }

    public LoadTag(long loadId) {
        LoadId = loadId;
    }

    public void setLoadId(long loadId) {
        LoadId = loadId;
    }

    public long getLoadId() {
        return LoadId;
    }
}
