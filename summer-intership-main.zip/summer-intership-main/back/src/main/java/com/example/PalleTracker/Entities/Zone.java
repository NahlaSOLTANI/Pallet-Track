package com.example.PalleTracker.Entities;

import com.fasterxml.jackson.annotation.JsonIgnore;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import java.text.SimpleDateFormat;
import java.util.Date;
@Document(collection ="Zone")

public class Zone {
    @Id
    @JsonIgnore
    private  Long zoneId;
    private  String zoneDesignation;
    private  String zoneDescription;
    private  Date zoneDateCreation;
    private  String zoneCreator ;
    private  boolean zoneActive ;

    public Zone( String zoneDesignation, String zoneDescription,String zoneCreator, boolean zoneActive, Date zoneDateCreation) {
        SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
        Date date = new Date(System.currentTimeMillis());

        this.zoneDesignation = zoneDesignation;
        this.zoneDescription = zoneDescription;
        this.zoneCreator = zoneCreator;
        this.zoneActive = zoneActive;
        this.zoneDateCreation=date;
    }

    public Zone() {
    }

    public Long getZoneId() {
        return zoneId;
    }

    public void setZoneId(Long zoneId) {
        this.zoneId = zoneId;
    }

    public String getZoneDesignation() {
        return zoneDesignation;
    }

    public void setZoneDesignation(String zoneDesignation) {
        this.zoneDesignation = zoneDesignation;
    }

    public String getZoneDescription() {
        return zoneDescription;
    }

    public void setZoneDescription(String zoneDescription) {
        this.zoneDescription = zoneDescription;
    }

    public Date getZoneDateCreation() {
        return zoneDateCreation;
    }

    public void setZoneDateCreation(Date zoneDateCreation) {
        this.zoneDateCreation = zoneDateCreation;
    }

    public String getZoneCreator() {
        return zoneCreator;
    }

    public void setZoneCreator(String zoneCreator) {
        this.zoneCreator = zoneCreator;
    }

    public boolean isZoneActive() {
        return zoneActive;
    }

    public void setZoneActive(boolean zoneActive) {
        this.zoneActive = zoneActive;
    }

    public String ztoString() {
        return "zone{" +
                "zoneID='" + getZoneId() + '\'' +
                ", zoneDesignation='" + getZoneDesignation()+ '\'' +
                ", zoneDescription='" + getZoneDescription()+ '\'' +
                ", zoneDateCreation=" + getZoneDateCreation() +
                ", zoneCreator=" + getZoneCreator() +
                ", zoneActive='" + isZoneActive() + '\'' +
                '}';
    }
}
