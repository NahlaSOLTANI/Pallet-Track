package com.example.PalleTracker.Controller;

import com.example.PalleTracker.Entities.DatabaseSequence;
import com.example.PalleTracker.Entities.Pallet;
import com.example.PalleTracker.Entities.Zone;
import com.example.PalleTracker.Repositories.DataBaseSequenceeRespository;
import com.example.PalleTracker.Repositories.PalletRepository;
import com.example.PalleTracker.Service.PalletService;
import org.joda.time.DateTimeZone;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.repository.Update;
import org.springframework.web.bind.annotation.*;

import java.text.SimpleDateFormat;
import java.time.ZoneId;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.TimeZone;

@RestController
public class PalletController {
    @Autowired
    private PalletService service ;
    @Autowired
    private DataBaseSequenceeRespository repo;

    @PostMapping("/addpallet")
    public String AddPallet(@RequestBody Pallet pallet){
        TimeZone.setDefault(TimeZone.getTimeZone("UTC"));

        Date date = new Date(System.currentTimeMillis());
        DateTimeZone timeZone = DateTimeZone.forID( "Africa/Tunis" );
        DatabaseSequence dbs=repo.findById("pallet");
        if( dbs==null ){
            dbs=new DatabaseSequence();
            dbs.setId("zone");
            dbs.setSeqVal(0);
            repo.save(dbs);
        }
        pallet.setPalletID(dbs.getSeqVal()+1);
        dbs.setSeqVal(dbs.getSeqVal()+1);
        repo.save(dbs);
        pallet.setPalletDateCreation(date);
        service.saveOrUpdatePallet(pallet);
        return "Zone added with id :" +pallet;}
    @CrossOrigin(origins = "*")
    @GetMapping("/pallets")
    public List<Pallet> getPallets (){
        return service.getPallets();
    }
    @GetMapping("/pallet/{id}")
    public Pallet getPallet(@PathVariable Long id){
        return service.gettById(id);   }
    @GetMapping("/palletByState/{state}")
    private List<Pallet> getPalletwithState(@PathVariable String state){
        return service.getStatePallet(state);
    }
    @DeleteMapping("/deletepallet/{id}")
    public String deletePallet(@PathVariable Long id){
        service.deletePallet(id);
        return "pallet deleted with id : "+id;
    }
    @PostMapping("/pallet")
    public Long savePallet(@RequestBody Pallet pallet)
    {
        service.saveOrUpdatePallet(pallet);
        return pallet.getPalletID();
    }
    @PutMapping("/findpallet/{id}")
    public Long updatePallet(@PathVariable Long id,@RequestBody Pallet pallet)
    {  TimeZone.setDefault(TimeZone.getTimeZone("UTC"));

        Date date = new Date(System.currentTimeMillis());
        DateTimeZone timeZone = DateTimeZone.forID( "Africa/Tunis" );
        pallet.setPalletDateCreation(date);
        pallet.setPalletID(id);
        service.saveOrUpdatePallet(pallet);
        return pallet.getPalletID();
    }
}