package com.example.PalleTracker.Repositories;

import com.example.PalleTracker.Entities.DatabaseSequence;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface DataBaseSequenceeRespository extends MongoRepository<DatabaseSequence,Long> {
    DatabaseSequence  findById(String id);

}
