package com.example.PalleTracker.Repositories;

import com.example.PalleTracker.Entities.User;
import com.example.PalleTracker.Entities.Zone;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface UserRepository extends MongoRepository<User,Long> {
}
