package com.example.PalleTracker.Repositories;
import com.example.PalleTracker.Entities.Pallet;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;
@RepositoryRestResource
public interface PalletRepository  extends MongoRepository<Pallet,Long>{
    //Pallet findPaletteById(Long id);
}
