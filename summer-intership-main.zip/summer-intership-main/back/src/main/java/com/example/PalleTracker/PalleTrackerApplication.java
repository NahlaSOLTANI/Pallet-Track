package com.example.PalleTracker;

import com.example.PalleTracker.Entities.Pallet;
import com.example.PalleTracker.Entities.Zone;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.text.SimpleDateFormat;
import java.util.Date;

@SpringBootApplication
public class PalleTrackerApplication implements CommandLineRunner {
	public static void main(String[] args) {
		SpringApplication.run(PalleTrackerApplication.class, args);
	}
	@Override
	public void run(String... args) throws Exception {
     System.out.println("hello");
		SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
		Date date = new Date(System.currentTimeMillis());
		Zone z=new Zone ( "cover ","machine de couverture  ","mayssa",true,date);
		System.out.println(z.ztoString());


	}
}
