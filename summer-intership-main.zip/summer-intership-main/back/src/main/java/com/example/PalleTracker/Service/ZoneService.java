package com.example.PalleTracker.Service;

import com.example.PalleTracker.Entities.Pallet;
import com.example.PalleTracker.Entities.Zone;
import com.example.PalleTracker.Repositories.PalletRepository;
import com.example.PalleTracker.Repositories.ZoneRespository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class ZoneService {
    @Autowired
    private ZoneRespository repository;

    public List<Zone> getZones() {
        return repository.findAll();

    }

    public Zone getZoneById(Long id) {
        return repository.findById(id).get();
    }

    public void saveOrUpdateZone(Zone zone) {
        repository.save(zone);
    }

    public void deletezone(Long id) {
        repository.deleteById(id);
    }

    public void update(Zone z, Long zoneid) {
        repository.save(z);
    }
    public List<Zone> getActiveZones(){
        List<Zone> list1 = getZones();
        List<Zone> listbyState=new ArrayList<>() ;
        for (Zone z : list1)
        {  if(z.isZoneActive()==true){
            listbyState.add(z);
        }
         System.out.println(listbyState);     }
        return listbyState;
}   public List<Zone> getInactiveZones(){
        List<Zone> list1 = getZones();
        List<Zone> listbyState=new ArrayList<>() ;
        for (Zone z : list1)
        {  if(z.isZoneActive()==false){
            listbyState.add(z);
        }
            System.out.println(listbyState);     }
        return listbyState;
    }
}