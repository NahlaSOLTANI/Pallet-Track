package com.example.PalleTracker.Entities;

import org.springframework.data.annotation.Id;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import java.util.List;

public class User {
    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    private  Long UserID;
    private  String UserName ;
    private List<Pallet> Pallets ;
    public User(Long userID, String userName) {
        UserID = userID;
        UserName = userName;
    }

    public User() {
    }

    public Long getUserID() {
        return UserID;
    }

    public void setUserID(Long userID) {
        UserID = userID;
    }

    public String getUserName() {
        return UserName;
    }

    public void setUserName(String userName) {
        UserName = userName;
    }

}
